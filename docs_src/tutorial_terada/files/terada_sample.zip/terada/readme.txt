Tsutsuji Trackcomputer Tutorial "寺田駅を作る" サンプルファイル

https://konawasabi.github.io/tsutsuji-trackcomputer/tutorial_terada/terada_index.html のサンプルファイルです。
上記チュートリアルで扱う全てのファイルを含んでいます。

main.cfg をTsutsuji Trackcomputerで読み込めば、関係する空中写真と各軌道データがプロットウィンドウに表示されます。
詳細は上記URLを参照してください。

作者: konawasabi
連絡先: webmaster@konawasabi.riceball.jp
Webサイト: https://konawasabi.riceball.jp/

Tsutsuji trackcomputer Tutorialサンプルファイル

Tsutsuji trackcomputer ( https://github.com/konawasabi/tsutsuji-trackcomputer )のtutorialで取り上げたサンプルファイルのアーカイブです。

route_example以下に、このtutorialで作成したデータをもとにしたシナリオデータをまとめてあります。
ストラクチャーとして、https://bvets.net/jp/edit/tutorial/ にて配布されているストラクチャーセットを同梱しています。
route_example\Structures以下のファイルの著作権はmackoy氏に帰属します。

作者: konawasabi
連絡先: webmaster@konawasabi.riceball.jp
Webサイト: https://konawasabi.riceball.jp/